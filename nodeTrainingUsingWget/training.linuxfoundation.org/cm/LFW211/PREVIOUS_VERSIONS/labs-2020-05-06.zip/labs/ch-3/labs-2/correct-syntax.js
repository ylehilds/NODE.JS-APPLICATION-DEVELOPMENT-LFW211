'use strict'

function f (a, b) {
  
}